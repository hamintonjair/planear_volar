<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/scripts.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url(); ?>assets/admin/assets/demo/chart-area-demo.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/datatables-simple-demo.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/jquery.dataTables.min.js"></script>
        <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
        <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_usuario.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_admin.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_configuracion.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_acerca.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_destino.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_paquetes.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_guias.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_vacantes.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_testimonio.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_clientes.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_reserva.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_mensajes.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_reservar_hotel.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/admin/function_oferta.js"></script>



    </body>
</html>
