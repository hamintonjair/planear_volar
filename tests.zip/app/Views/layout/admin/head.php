<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Jojama" />
        <meta name="author" content="Jojama" />
        <link href="<?php echo base_url(); ?>assets/img/favicon.ico" rel="icon">

        <title>Planear - Volar</title>
        <link href="<?php echo base_url(); ?>assets/admin/css/dist_style.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/admin/css/styles.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/admin/css/dataTables.dataTables.min.css" rel="stylesheet" />
        <script src="<?php echo base_url(); ?>assets/admin/js/all.min.js" crossorigin="anonymous"></script>
        <link href="<?php echo base_url(); ?>assets/admin/css/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    </head>