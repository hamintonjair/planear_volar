<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Twilio extends BaseConfig
{
    public $account_sid = 'AC3e55e342d023cce0fc5bce80b06d4121';
    public $auth_token = 'f349d9d81d6859ca8b39c2980eca768f';
    public $from_number = '+12622289140';
}
